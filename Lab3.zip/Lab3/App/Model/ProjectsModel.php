<?php 

namespace App\Model;

class ProjectsModel{
 
}